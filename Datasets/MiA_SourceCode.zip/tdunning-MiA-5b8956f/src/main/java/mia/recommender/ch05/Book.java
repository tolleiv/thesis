package mia.recommender.ch05;

interface Book {

  Genre getGenre();
  
  boolean isOutOfStock();

}
